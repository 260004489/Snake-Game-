import pygame
import main
from pygame.math import Vector2
from pygame import mixer

# Initialize pygame
pygame.init()
cell_size = 40
cell_number = 20

# Open a window and create a background image
screen = pygame.display.set_mode((cell_number * cell_size, cell_number * cell_size))

# Load image for background and food 
background_image = pygame.image.load("Image/grass.png").convert_alpha()
cherry = pygame.image.load("Image/cherry.png").convert_alpha()
# Set tile to the window

pygame.display.set_caption("Snake game")

# Create a clock for frame rate
clock = pygame.time.Clock()

# Load back ground music to the game
mixer.music.load("Sound_effect/back_ground_music.mp3")
mixer.music.play(-1)

# Create main object and set the frame rate of screen
main_game = main.MAIN()
SCREEN_UPDATE = pygame.USEREVENT
pygame.time.set_timer(SCREEN_UPDATE,150) # 150ms frame rate

# Score Font
game_font = pygame.font.Font('Font/WT.otf',50)

# Read user event
while(True):
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == SCREEN_UPDATE:
            main_game.update()


        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                if main_game.snake.direction.y != 1:
                    main_game.snake.direction = Vector2(0,-1)

            if event.key == pygame.K_LEFT:
                if main_game.snake.direction.x != 1:
                    main_game.snake.direction = Vector2(-1,0)
            if event.key == pygame.K_RIGHT:
                if main_game.snake.direction.x != -1:
                    main_game.snake.direction = Vector2(1,0)
            if event.key == pygame.K_DOWN:
                if main_game.snake.direction.y != -1:
                    main_game.snake.direction = Vector2(0,1)


    screen.blit(background_image,[0, 0])
    main_game.draw_object(screen,cherry,game_font)
    pygame.display.update()
    clock.tick(60)

