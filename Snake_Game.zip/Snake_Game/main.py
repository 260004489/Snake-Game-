import pygame
import Snake
import Food
import sys
cell_size = 40
cell_number = 20


class MAIN:
    def __init__(self):
        self.snake = Snake.SNAKE()
        self.food = Food.FOOD()

    def update(self):
        self.snake.move()
        self.check_collision()
        self.check_fail()

    def draw_object(self,screen,cherry,game_font):
        self.food.draw_food(screen,cherry)
        self.snake.draw_snake(screen)
        self.draw_score(screen,game_font)

    def check_collision(self):
        if self.food.pos == self.snake.body[0]:
            self.food.generate()
            self.snake.add()
            self.snake.play_crunch_sound()

        for block in self.snake.body[1:]:
            if block == self.food.pos:
                self.food.generate()

    def check_fail(self):
        if not 0 <= self.snake.body[0].x < cell_number or not 0 <= self.snake.body[0].y < cell_number:
            self.game_over()


        for block in self.snake.body[1:]:
            if block == self.snake.body[0]:
                self.game_over()

    def game_over(self):
        pygame.quit()
        sys.exit()


    def draw_score(self,screen,game_font):
        score_text = "Score: " + str(len(self.snake.body)-3)
        score_surface = game_font.render(score_text,True,(220,20,60))
        screen_x = int(cell_size*cell_number/2)
        screen_y = int(cell_size * cell_number/15)
        score_rect = score_surface.get_rect(center = (screen_x,screen_y))
        background_rect = pygame.Rect(score_rect.left-10,score_rect.top+5,score_rect.width+20,score_rect.height-10)
        pygame.draw.rect(screen, (255, 255, 255), background_rect)
        screen.blit(score_surface,score_rect)
        pygame.draw.rect(screen, (220,20,60), background_rect,3)