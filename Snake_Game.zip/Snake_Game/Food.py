import pygame
import random
from pygame.math import Vector2


cell_size = 40
cell_number = 20


class FOOD:
    def __init__(self):
        self.generate()


    def draw_food(self,screen,cherry):
        x_pos = int(self.pos.x * cell_size)
        y_pos = int(self.pos.y * cell_size)
        fruit_rect = pygame.Rect(x_pos,y_pos,cell_size,cell_size)
        screen.blit(cherry, fruit_rect)

    def generate(self):
        self.x = random.randint(0, cell_number - 2)
        self.y = random.randint(0, cell_number - 2)
        self.pos = Vector2(self.x, self.y)
