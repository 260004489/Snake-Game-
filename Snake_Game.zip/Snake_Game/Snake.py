import pygame
import random
from pygame.math import Vector2

cell_size = 40

class SNAKE:
    def __init__(self):
        self.body = [Vector2(7,10),Vector2(6,10),Vector2(5,10)]
        self.direction = Vector2(1,0)
        self.add_body = False

        self.head_up = pygame.image.load("Image/head_up.png").convert_alpha()
        self.head_down = pygame.image.load("Image/head_down.png").convert_alpha()
        self.head_left = pygame.image.load("Image/head_left.png").convert_alpha()
        self.head_right = pygame.image.load("Image/head_right.png").convert_alpha()

        self.tail_up = pygame.image.load("Image/tail_up.png").convert_alpha()
        self.tail_down = pygame.image.load("Image/tail_down.png").convert_alpha()
        self.tail_left = pygame.image.load("Image/tail_left.png").convert_alpha()
        self.tail_right = pygame.image.load("Image/tail_right.png").convert_alpha()

        self.body_dr = pygame.image.load("Image/body_dr.png").convert_alpha()
        self.body_ld = pygame.image.load("Image/body_ld.png").convert_alpha()
        self.body_lu = pygame.image.load("Image/body_lu.png").convert_alpha()
        self.body_ur = pygame.image.load("Image/body_ur.png").convert_alpha()

        self.body_vertical = pygame.image.load("Image/body_vertical.png").convert_alpha()
        self.body_horizontal = pygame.image.load("Image/body_horizontal.png").convert_alpha()

        self.crunch_sound = pygame.mixer.Sound('Sound_effect/crunch.wav')
    
    def draw_snake(self,screen):
        self.update_head_image()
        self.update_tail_image()
        
        for index,block in enumerate(self.body):
            x_pos = int(block.x*cell_size)
            y_pos = block.y * cell_size
            block_rect = pygame.Rect(x_pos, y_pos, cell_size, cell_size)

            if index==0:
                screen.blit(self.head,block_rect)
            elif index== len(self.body)-1:
                screen.blit(self.tail, block_rect)
            else:
                previous_block = self.body[index+1]-block
                next_block = self.body[index-1]-block
                if(previous_block.x == next_block.x):
                    screen.blit(self.body_vertical, block_rect)
                elif(previous_block.y == next_block.y):
                    screen.blit(self.body_horizontal, block_rect)
                else:
                    if((previous_block.x == -1 and next_block.y == -1) or (previous_block.y == -1 and next_block.x == -1)):
                        screen.blit(self.body_lu,block_rect)
                    elif((previous_block.x == 1 and next_block.y == -1) or (previous_block.y == -1 and next_block.x == 1)):
                        screen.blit(self.body_ur, block_rect)
                    elif((previous_block.x == 1 and next_block.y == 1) or (previous_block.y == 1 and next_block.x == 1)):
                        screen.blit(self.body_dr, block_rect)
                    elif((previous_block.x == -1 and next_block.y == 1) or (previous_block.y == 1 and next_block.x == -1)):
                        screen.blit(self.body_ld, block_rect)

    def update_head_image(self):
        relation = self.body[1] - self.body[0]
        if relation == Vector2(1,0):
            self.head = self.head_left
        elif relation == Vector2(-1,0):
            self.head = self.head_right
        elif relation == Vector2(0, 1):
            self.head = self.head_up
        else:
            self.head = self.head_down

    def update_tail_image(self):
        relation = self.body[len(self.body)-2] - self.body[len(self.body)-1]
        if relation == Vector2(1,0):
            self.tail = self.tail_left
        elif relation == Vector2(-1,0):
            self.tail = self.tail_right
        elif relation == Vector2(0, 1):
            self.tail = self.tail_up
        else:
            self.tail = self.tail_down

    def move(self):
        if(self.add_body==True):
            new_body = self.body[:]
            new_body.insert(0, new_body[0] + self.direction)
            self.body = new_body[:]
            self.add_body = False
        else:
            new_body = self.body[:-1]
            new_body.insert(0,new_body[0] + self.direction)
            self.body = new_body[:]

    def add(self):
        self.add_body = True

    def play_crunch_sound(self):
        self.crunch_sound.play()

